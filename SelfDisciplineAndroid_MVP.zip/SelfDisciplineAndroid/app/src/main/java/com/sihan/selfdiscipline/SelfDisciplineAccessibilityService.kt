package com.sihan.selfdiscipline

import android.accessibilityservice.AccessibilityService
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.media.MediaPlayer
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.accessibility.AccessibilityEvent

class SelfDisciplineAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var windowManager: WindowManager? = null
    private var currentOverlay: View? = null
    private var currentPackage: String? = null
    private var lastEventAt = 0L
    private var tempAllowedUntil = 0L
    private var tempAllowedPackage: String? = null
    private var player: MediaPlayer? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        if (pkg == packageName) return
        val now = System.currentTimeMillis()
        if (pkg == currentPackage && now - lastEventAt < 800) return
        lastEventAt = now
        currentPackage = pkg
        evaluatePackage(pkg)
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        removeOverlay()
        stopSound()
        super.onDestroy()
    }

    private fun evaluatePackage(pkg: String) {
        val mode = AppPrefs.mode(this, pkg)
        if (mode == AppPrefs.Mode.BLOCK) {
            if (tempAllowedPackage == pkg && System.currentTimeMillis() < tempAllowedUntil) return
            performGlobalAction(GLOBAL_ACTION_HOME)
            showBlockingOverlay(pkg)
            playSound(AppPrefs.blockSound(this))
        } else if (mode == AppPrefs.Mode.WELCOME) {
            showWelcomeOverlay()
            playSound(AppPrefs.welcomeSound(this))
        } else {
            removeOverlay()
        }
    }

    private fun showBlockingOverlay(pkg: String) {
        removeOverlay()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(28), dp(24), dp(28), dp(24))
            setBackgroundColor(Color.argb(248, 247, 248, 252))
            isClickable = true
        }
        val title = TextView(this).apply {
            text = "先停一下"
            textSize = 28f
            setTextColor(Color.rgb(22, 24, 29))
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        root.addView(title, lp(-1, -2, 0, 12))
        val message = TextView(this).apply {
            text = AppPrefs.blockMessage(this@SelfDisciplineAccessibilityService)
            textSize = 19f
            setTextColor(Color.rgb(55, 60, 70))
            gravity = Gravity.CENTER
        }
        root.addView(message, lp(-1, -2, 0, 20))

        val back = Button(this).apply {
            text = "回到桌面"
            setTextColor(Color.WHITE)
            background = ColorDrawable(Color.rgb(54, 92, 245))
            setOnClickListener {
                performGlobalAction(GLOBAL_ACTION_HOME)
                removeOverlay()
            }
        }
        root.addView(back, lp(-1, -2, 0, 8))

        val continueButton = Button(this).apply {
            text = "我确定，进入 5 分钟"
            setOnClickListener {
                tempAllowedPackage = pkg
                tempAllowedUntil = System.currentTimeMillis() + 5 * 60 * 1000L
                removeOverlay()
                openPackage(pkg)
            }
        }
        root.addView(continueButton, lp(-1, -2, 0, 0))
        addOverlay(root, true)
    }

    private fun showWelcomeOverlay() {
        removeOverlay()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(22), dp(16), dp(22), dp(16))
            setBackgroundColor(Color.argb(235, 230, 250, 239))
            isClickable = false
        }
        val text = TextView(this).apply {
            text = AppPrefs.welcomeMessage(this@SelfDisciplineAccessibilityService)
            textSize = 18f
            setTextColor(Color.rgb(35, 90, 58))
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        root.addView(text)
        addOverlay(root, false)
        handler.postDelayed({ removeOverlay() }, 1800)
    }

    private fun addOverlay(view: View, blocking: Boolean) {
        val type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
        val flags = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            if (blocking) WindowManager.LayoutParams.MATCH_PARENT else WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            flags,
            android.graphics.PixelFormat.TRANSLUCENT
        ).apply {
            gravity = if (blocking) Gravity.CENTER else Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = if (blocking) 0 else dp(70)
        }
        try {
            windowManager?.addView(view, params)
            currentOverlay = view
        } catch (_: Exception) {
            currentOverlay = null
        }
    }

    private fun removeOverlay() {
        currentOverlay?.let {
            try { windowManager?.removeView(it) } catch (_: Exception) { }
        }
        currentOverlay = null
    }

    private fun openPackage(pkg: String) {
        val launchIntent = packageManager.getLaunchIntentForPackage(pkg) ?: return
        launchIntent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        try { startActivity(launchIntent) } catch (_: Exception) { }
    }

    private fun playSound(uriString: String?) {
        stopSound()
        if (uriString.isNullOrBlank()) {
            try {
                val tone = android.media.ToneGenerator(android.media.AudioManager.STREAM_NOTIFICATION, 80)
                tone.startTone(android.media.ToneGenerator.TONE_PROP_BEEP2, 180)
                handler.postDelayed({ tone.release() }, 250)
            } catch (_: Exception) { }
            return
        }
        try {
            player = MediaPlayer.create(this, Uri.parse(uriString))?.also {
                it.setOnCompletionListener { mp ->
                    mp.release()
                    if (player === mp) player = null
                }
                it.start()
            }
        } catch (_: Exception) {
            player = null
        }
    }

    private fun stopSound() {
        try { player?.stop() } catch (_: Exception) { }
        try { player?.release() } catch (_: Exception) { }
        player = null
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun lp(w: Int, h: Int, top: Int, bottom: Int): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(w, h).apply { topMargin = dp(top); bottomMargin = dp(bottom) }
}
