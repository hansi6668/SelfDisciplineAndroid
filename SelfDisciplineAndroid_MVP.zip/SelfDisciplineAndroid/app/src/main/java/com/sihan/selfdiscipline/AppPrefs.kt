package com.sihan.selfdiscipline

import android.content.Context

object AppPrefs {
    private const val NAME = "self_discipline"
    private const val KEY_BLOCKED = "blocked_apps"
    private const val KEY_WELCOME = "welcome_apps"
    private const val KEY_BLOCK_MESSAGE = "block_message"
    private const val KEY_WELCOME_MESSAGE = "welcome_message"
    private const val KEY_BLOCK_SOUND = "block_sound"
    private const val KEY_WELCOME_SOUND = "welcome_sound"

    private fun prefs(context: Context) = context.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    private fun getSet(context: Context, key: String): MutableSet<String> =
        prefs(context).getStringSet(key, emptySet())?.toMutableSet() ?: mutableSetOf()

    fun blockedApps(context: Context): Set<String> = getSet(context, KEY_BLOCKED)
    fun welcomeApps(context: Context): Set<String> = getSet(context, KEY_WELCOME)

    fun setMode(context: Context, packageName: String, mode: Mode) {
        val p = prefs(context)
        val blocked = getSet(context, KEY_BLOCKED)
        val welcome = getSet(context, KEY_WELCOME)
        blocked.remove(packageName)
        welcome.remove(packageName)
        when (mode) {
            Mode.BLOCK -> blocked.add(packageName)
            Mode.WELCOME -> welcome.add(packageName)
            Mode.OFF -> Unit
        }
        p.edit().putStringSet(KEY_BLOCKED, blocked).putStringSet(KEY_WELCOME, welcome).apply()
    }

    fun mode(context: Context, packageName: String): Mode = when {
        packageName in blockedApps(context) -> Mode.BLOCK
        packageName in welcomeApps(context) -> Mode.WELCOME
        else -> Mode.OFF
    }

    fun blockMessage(context: Context): String = prefs(context).getString(KEY_BLOCK_MESSAGE, null)
        ?: "先停一下。\n你真的需要现在打开这个应用吗？"

    fun welcomeMessage(context: Context): String = prefs(context).getString(KEY_WELCOME_MESSAGE, null)
        ?: "欢迎回来。\n先完成重要的事，再享受娱乐。"

    fun setBlockMessage(context: Context, value: String) =
        prefs(context).edit().putString(KEY_BLOCK_MESSAGE, value).apply()

    fun setWelcomeMessage(context: Context, value: String) =
        prefs(context).edit().putString(KEY_WELCOME_MESSAGE, value).apply()

    fun blockSound(context: Context): String? = prefs(context).getString(KEY_BLOCK_SOUND, null)
    fun welcomeSound(context: Context): String? = prefs(context).getString(KEY_WELCOME_SOUND, null)

    fun setBlockSound(context: Context, uri: String?) =
        prefs(context).edit().putString(KEY_BLOCK_SOUND, uri).apply()

    fun setWelcomeSound(context: Context, uri: String?) =
        prefs(context).edit().putString(KEY_WELCOME_SOUND, uri).apply()

    enum class Mode { BLOCK, WELCOME, OFF }
}
