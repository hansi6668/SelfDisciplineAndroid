package com.sihan.selfdiscipline

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var appList: LinearLayout
    private lateinit var serviceStatus: TextView
    private lateinit var blockEdit: EditText
    private lateinit var welcomeEdit: EditText

    private val pickBlockSound = 1001
    private val pickWelcomeSound = 1002

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        refreshUi()
    }

    override fun onResume() {
        super.onResume()
        refreshUi()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(247, 248, 252)) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(30))
        }
        scroll.addView(root)

        val title = TextView(this).apply {
            text = "自律一下"
            textSize = 30f
            setTextColor(Color.rgb(22, 24, 29))
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        root.addView(title)
        root.addView(textView("把手机变成一个会提醒你的环境。", 15f, Color.DKGRAY, 0, 6))

        val statusCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setBackgroundColor(Color.WHITE)
        }
        root.addView(statusCard, lp(-1, -2, 18))
        serviceStatus = textView("正在检测监控服务…", 16f, Color.DKGRAY, 0, 4)
        statusCard.addView(serviceStatus)
        val serviceBtn = Button(this).apply {
            text = "开启/检查自律监控"
            setOnClickListener { openAccessibilitySettings() }
        }
        statusCard.addView(serviceBtn, lp(-1, -2, 4))

        root.addView(sectionTitle("1. 设置你的提示文字"))
        blockEdit = EditText(this).apply {
            hint = "进入不想打开的应用时显示的文字"
            minLines = 3
            gravity = Gravity.TOP
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            setText(AppPrefs.blockMessage(this@MainActivity))
        }
        root.addView(blockEdit, lp(-1, -2, 6))
        root.addView(button("保存拦截提示", Color.rgb(54, 92, 245)) {
            AppPrefs.setBlockMessage(this, blockEdit.text.toString().trim().ifEmpty { "先停一下。\n你真的需要现在打开这个应用吗？" })
            toast("已保存")
        }, lp(-1, -2, 8))

        welcomeEdit = EditText(this).apply {
            hint = "打开想保持自律的应用时显示的文字"
            minLines = 3
            gravity = Gravity.TOP
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            setText(AppPrefs.welcomeMessage(this@MainActivity))
        }
        root.addView(welcomeEdit, lp(-1, -2, 6))
        root.addView(button("保存鼓励提示", Color.rgb(45, 157, 99)) {
            AppPrefs.setWelcomeMessage(this, welcomeEdit.text.toString().trim().ifEmpty { "欢迎回来。\n先完成重要的事，再享受娱乐。" })
            toast("已保存")
        }, lp(-1, -2, 10))

        root.addView(sectionTitle("2. 提示音 / 自定义音乐"))
        root.addView(button("选择拦截提示音", Color.rgb(95, 103, 120)) {
            openAudioPicker(pickBlockSound)
        }, lp(-1, -2, 4))
        root.addView(button("选择鼓励提示音", Color.rgb(95, 103, 120)) {
            openAudioPicker(pickWelcomeSound)
        }, lp(-1, -2, 12))

        root.addView(sectionTitle("3. 选择需要自律的应用"))
        root.addView(textView("每个应用只能处于一种状态：关闭 / 拦截 / 鼓励。", 14f, Color.DKGRAY, 0, 8))
        appList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(appList)

        root.addView(textView("说明：第一次使用时必须在系统“无障碍”设置中手动开启“自律一下前台应用监控”。该服务只读取前台应用包名，不读取窗口文字内容。", 12f, Color.GRAY, 18, 0))
        setContentView(scroll)
    }

    private fun refreshUi() {
        if (!::serviceStatus.isInitialized) return
        val enabled = isAccessibilityEnabled()
        serviceStatus.text = if (enabled) "● 自律监控已开启" else "○ 自律监控未开启"
        serviceStatus.setTextColor(if (enabled) Color.rgb(45, 157, 99) else Color.rgb(217, 54, 62))
        refreshApps()
    }

    private fun refreshApps() {
        appList.removeAllViews()
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val homePackage = pm.resolveActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME),
            PackageManager.MATCH_DEFAULT_ONLY
        )?.activityInfo?.packageName
        val excludedPackages = setOfNotNull(
            packageName,
            homePackage,
            "com.android.settings",
            "com.google.android.packageinstaller",
            "com.android.packageinstaller"
        )
        val apps = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .filter { it.activityInfo.packageName !in excludedPackages }
            .distinctBy { it.activityInfo.packageName }
            .map {
                val ai = it.activityInfo.applicationInfo
                AppItem(
                    ai.packageName,
                    ai.loadLabel(pm).toString(),
                    ai.loadIcon(pm)
                )
            }
            .sortedBy { it.label.lowercase(Locale.getDefault()) }

        for (app in apps) addAppRow(app)
    }

    private fun addAppRow(app: AppItem) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(12), dp(10))
            setBackgroundColor(Color.WHITE)
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val icon = ImageView(this).apply { setImageDrawable(app.icon) }
        top.addView(icon, lp(dp(40), dp(40), 0))
        val name = TextView(this).apply {
            text = app.label
            textSize = 16f
            setTextColor(Color.rgb(22, 24, 29))
            setPadding(dp(12), 0, dp(8), 0)
        }
        top.addView(name, LinearLayout.LayoutParams(0, -2, 1f))
        card.addView(top)

        val group = RadioGroup(this).apply {
            orientation = RadioGroup.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val off = RadioButton(this).apply { text = "关闭"; id = View.generateViewId() }
        val block = RadioButton(this).apply { text = "拦截"; id = View.generateViewId() }
        val welcome = RadioButton(this).apply { text = "鼓励"; id = View.generateViewId() }
        group.addView(off, LinearLayout.LayoutParams(0, -2, 1f))
        group.addView(block, LinearLayout.LayoutParams(0, -2, 1f))
        group.addView(welcome, LinearLayout.LayoutParams(0, -2, 1f))
        when (AppPrefs.mode(this, app.packageName)) {
            AppPrefs.Mode.OFF -> off.isChecked = true
            AppPrefs.Mode.BLOCK -> block.isChecked = true
            AppPrefs.Mode.WELCOME -> welcome.isChecked = true
        }
        group.setOnCheckedChangeListener { _, checkedId ->
            val mode = when (checkedId) {
                block.id -> AppPrefs.Mode.BLOCK
                welcome.id -> AppPrefs.Mode.WELCOME
                else -> AppPrefs.Mode.OFF
            }
            AppPrefs.setMode(this, app.packageName, mode)
        }
        card.addView(group)
        appList.addView(card, lp(-1, -2, 0, 8))
    }

    private fun openAudioPicker(requestCode: Int) {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "audio/*"
            addCategory(Intent.CATEGORY_OPENABLE)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, requestCode)
    }

    @Deprecated("Kept for compatibility with the MVP code path")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) { }
        when (requestCode) {
            pickBlockSound -> AppPrefs.setBlockSound(this, uri.toString())
            pickWelcomeSound -> AppPrefs.setWelcomeSound(this, uri.toString())
        }
        toast("提示音已保存")
    }

    private fun openAccessibilitySettings() {
        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }

    private fun isAccessibilityEnabled(): Boolean {
        val expected = ComponentName(this, SelfDisciplineAccessibilityService::class.java)
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        return enabled.split(':').any { ComponentName.unflattenFromString(it) == expected }
    }

    private fun textView(text: String, size: Float, color: Int, top: Int, bottom: Int): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        if (top != 0 || bottom != 0) setPadding(0, dp(top), 0, dp(bottom))
    }

    private fun sectionTitle(text: String): TextView = textView(text, 19f, Color.rgb(22, 24, 29), 16, 8).apply {
        typeface = android.graphics.Typeface.DEFAULT_BOLD
    }

    private fun button(text: String, color: Int, action: () -> Unit): Button = Button(this).apply {
        this.text = text
        setTextColor(Color.WHITE)
        background = ColorDrawable(color)
        setOnClickListener { action() }
    }

    private fun lp(width: Int, height: Int, top: Int = 0, bottom: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(width, height).apply { topMargin = dp(top); bottomMargin = dp(bottom) }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    data class AppItem(val packageName: String, val label: String, val icon: android.graphics.drawable.Drawable)
}
